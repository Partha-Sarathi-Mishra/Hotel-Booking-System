package com.partha.spring201.dao;

import java.util.List;

import com.partha.spring201.model.BookingDetails;

public interface BookRoomDao {

	public void bookRoom(BookingDetails bookingDetails);

	public List getUniquebookingId();

}
