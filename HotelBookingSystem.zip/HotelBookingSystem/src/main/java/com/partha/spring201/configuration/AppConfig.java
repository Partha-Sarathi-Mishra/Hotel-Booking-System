package com.partha.spring201.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.partha.spring201.aspect.ApplicationAspects;
import com.partha.spring201.controller.BookRoomController;
import com.partha.spring201.controller.BookingPageController;
import com.partha.spring201.controller.LoginController;
import com.partha.spring201.controller.LoginHomePageController;
import com.partha.spring201.controller.LogoutController;
import com.partha.spring201.controller.RegistrationController;
import com.partha.spring201.dao.BookRoomDao;
import com.partha.spring201.dao.BookRoomDaoImpl;
import com.partha.spring201.dao.LoginDao;
import com.partha.spring201.dao.LoginDaoImpl;
import com.partha.spring201.dao.LoginHomePageDao;
import com.partha.spring201.dao.LoginHomePageDaoImpl;
import com.partha.spring201.dao.RegistrationDao;
import com.partha.spring201.dao.RegistrationDaoImpl;
import com.partha.spring201.model.BookingDetails;
import com.partha.spring201.model.Hotel;
import com.partha.spring201.model.User;
import com.partha.spring201.service.BookRoomService;
import com.partha.spring201.service.BookRoomServiceImpl;
import com.partha.spring201.service.LoginHomePageService;
import com.partha.spring201.service.LoginHomePageServiceImpl;
import com.partha.spring201.service.LoginService;
import com.partha.spring201.service.LoginServiceImpl;
import com.partha.spring201.service.RegistrationService;
import com.partha.spring201.service.RegistrationServiceImpl;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = {"com.partha.spring201"})
public class AppConfig extends WebMvcConfigurerAdapter{
	/**
     * Configure ViewResolvers to deliver preferred views.
     */
	@Bean
	public InternalResourceViewResolver viewResolver(){
		InternalResourceViewResolver resolver= new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	}
	
	/**
     * Configure ResourceHandlers to serve static resources like CSS/ Javascript etc...
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("/static/");
    }
    /**
     * Configure MessageSource to lookup any validation/error message in internationalized property files
     */
    @Bean
	public MessageSource messageSource() {
	    ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
	    messageSource.setBasename("messages");
	    return messageSource;
	}
    
    /**Optional. It's only required when handling '.' in @PathVariables which otherwise ignore everything after last '.' in @PathVaidables argument.
     * It's a known bug in Spring [https://jira.spring.io/browse/SPR-6164], still present in Spring 4.1.7.
     * This is a workaround for this issue.
     */
    @Override
    public void configurePathMatch(PathMatchConfigurer matcher) {
        matcher.setUseRegisteredSuffixPatternMatch(true);
    }
    @Bean
	@Autowired
	public RegistrationController registrationController(){
		return new RegistrationController();
	}
	@Bean
	@Autowired
	public RegistrationService registrationService(){
		return new RegistrationServiceImpl();
	}
	@Bean
	@Autowired
	public RegistrationDao registrationDao(){
		return new RegistrationDaoImpl();
	}
	@Bean
	@Autowired
	public User user(){
		return new User();
	}
	
	@Bean
	@Autowired
	public LoginController loginController(){
		return new LoginController();
	}
	@Bean
	@Autowired
	public LoginService loginService(){
		return new LoginServiceImpl();
	}
	@Bean
	@Autowired
	public LoginDao loginDao(){
		return new LoginDaoImpl();
	}
	
	
	@Bean
	@Autowired
	public Hotel hotel(){
		return new Hotel();
	}
	
	@Bean
	@Autowired
	public LoginHomePageController loginHomePageController(){
		return new LoginHomePageController();
	}
	@Bean
	@Autowired
	public LoginHomePageService loginHomePageService(){
		return new LoginHomePageServiceImpl();
	}
	@Bean
	@Autowired
	public LoginHomePageDao loginHomePageDao(){
		return new LoginHomePageDaoImpl();
	}
	
	@Bean
	@Autowired
	public BookingPageController bookingPageController(){
		return new BookingPageController();
	}
	@Bean
	@Autowired
	public BookRoomController bookRoomController(){
		return new BookRoomController();
	}
	@Bean
	@Autowired
	public BookRoomService bookRoomService(){
		return new BookRoomServiceImpl();
	}
	@Bean
	@Autowired
	public BookRoomDao bookRoomDao(){
		return new BookRoomDaoImpl();
	}
	@Bean
	@Autowired
	public BookingDetails bookingDetails(){
		return new BookingDetails();
	}
	@Bean
	@Autowired
	public LogoutController	 logoutController(){
		return new LogoutController();
	}
	@Bean
	@Autowired
	public ApplicationAspects applicationAspects(){
		return new ApplicationAspects();
	}
}