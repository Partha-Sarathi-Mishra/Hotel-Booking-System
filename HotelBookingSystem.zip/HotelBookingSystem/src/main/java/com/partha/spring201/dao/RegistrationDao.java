package com.partha.spring201.dao;

import com.partha.spring201.model.User;

public interface RegistrationDao {
	
	public void saveUserInfo(User user);
}
