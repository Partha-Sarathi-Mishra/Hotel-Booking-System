package com.partha.spring201.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.partha.spring201.model.Hotel;

@ComponentScan("com.partha.spring201.configuration")
@Repository
public class LoginHomePageDaoImpl implements LoginHomePageDao {
	@Autowired
	SessionFactory sessionFactory;

	public List<Hotel> getHotelsByCity(String selectedCity) {
		Session session=this.sessionFactory.openSession();
		 Query query=session.createQuery("from Hotel hotel where hotel.city= :selectedCity group by hotel.tarrif_per_day");  
		 query.setParameter("selectedCity", selectedCity);  
		 @SuppressWarnings("unchecked")
		List<Hotel> hotelList=query.list();
		   session.close();
		return hotelList;
	}
}