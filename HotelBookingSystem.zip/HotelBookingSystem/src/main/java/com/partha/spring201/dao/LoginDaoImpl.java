package com.partha.spring201.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.partha.spring201.model.User;

@Repository
@ComponentScan("com.partha.spring201.configuration")
public class LoginDaoImpl implements LoginDao{

	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	User user;
	@SuppressWarnings("rawtypes")
	public List retriveUserUsernameAndPassword(String username, String password) {
		
			Session session = this.sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql="FROM User user WHERE user.username= :username and user.password= :password";
			Query query=session.createQuery(hql);  
			query.setParameter("username", username); 
			query.setParameter("password", password); 
			List user = query.list();
		//	 List<Hotel> hotelList=query.list();
			
			tx.commit();
			session.close();
				return user;
	}

}
