package com.partha.spring201.service;

import java.util.List;

public interface LoginService {
	@SuppressWarnings("rawtypes")
	public List performLogin(String username,String Password);
}
