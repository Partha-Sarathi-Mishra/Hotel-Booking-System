package com.partha.spring201.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.partha.spring201.dao.LoginDao;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginDao loginDao;
	@SuppressWarnings("rawtypes")
	public List performLogin(String username, String password) {
		List user=loginDao.retriveUserUsernameAndPassword(username, password);
		return user;
		
	}

}
