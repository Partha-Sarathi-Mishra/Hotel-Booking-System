package com.partha.spring201.service;


public interface RegistrationService {

	public void saveUserInfo(String firstName, String lastName, String username, String password);
}
