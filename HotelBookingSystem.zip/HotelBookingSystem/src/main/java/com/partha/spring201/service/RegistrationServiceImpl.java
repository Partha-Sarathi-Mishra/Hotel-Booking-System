package com.partha.spring201.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.partha.spring201.dao.RegistrationDao;
import com.partha.spring201.model.User;
@Service
public class RegistrationServiceImpl implements RegistrationService {
	
	@Autowired
	RegistrationDao registrationDao;

	User user = new User();
	
	public void saveUserInfo(String firstName, String lastName, String username, String password) {
		
		user.setUser_first_name(firstName);
		user.setUser_last_name(lastName);
		user.setUsername(username);
		user.setPassword(password);
		System.out.println(user);
		registrationDao.saveUserInfo(user);
		
	}

}
