package com.partha.spring201.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.partha.spring201.model.Hotel;
import com.partha.spring201.service.LoginHomePageService;

@Controller
@ComponentScan("com.partha.spring201.configuration")
@Scope("session")
@SessionAttributes("hotelList")
public class LoginHomePageController {
	
	@Autowired
	LoginHomePageService loginHomePageService;
	
	@RequestMapping(value="/searchHotelsByCity", method=RequestMethod.POST)
	public String getAllHotelsInTheCity(@RequestParam("selectedCity") String selectedCity,
			ModelMap model){
		List<Hotel> hotelList = loginHomePageService.getHotelsByCity(selectedCity);
		model.put("hotelList",hotelList);
		return "hotelListInTheCity";
	}
	@RequestMapping(value="/viewLowestPriceHotels", method=RequestMethod.POST)
	public String getLowestPricedHotelsByCity(@RequestParam("selectedCity") String selectedCity,
			ModelMap model){
		List<Hotel> hotelList = loginHomePageService.getHotelsByCity(selectedCity);
		model.put("hotelList",hotelList);
		return "lowestPriceHotels";
	}
}
