package com.partha.spring201.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.partha.spring201.model.User;

@ComponentScan("com.partha.spring201.configuration")
@Repository
public class RegistrationDaoImpl implements RegistrationDao{
	
	
	@Autowired
	SessionFactory sessionFactory;
	public void saveUserInfo(User user) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(user);
		tx.commit();
		session.close();
	}
	
}
