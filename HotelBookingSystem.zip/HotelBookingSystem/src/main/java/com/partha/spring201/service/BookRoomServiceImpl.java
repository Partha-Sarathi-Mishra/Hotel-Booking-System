package com.partha.spring201.service;

import java.awt.print.Book;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.partha.spring201.dao.BookRoomDao;
import com.partha.spring201.model.BookingDetails;
import com.partha.spring201.model.Hotel;
import com.partha.spring201.model.User;

@Service
public class BookRoomServiceImpl implements BookRoomService{

	@Autowired 
	private BookRoomDao bookRoomDao;
	
	@Autowired
	private BookingDetails bookingDetails;
	
	@Autowired
	private User user;

	@Autowired
	private Hotel hotel;
	
	public int bookRoom(String checkInDate, String checkOutDate,
			Integer noOfRooms, Integer hotelId, Integer userId,
			Integer tarrifPerDay) {
		DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date checkinDate = null;
		Date checkoutDate = null;
        try {
            //Convert String to Date
        	checkinDate = sdf.parse(checkInDate);
            checkoutDate= sdf.parse(checkOutDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long diff = checkoutDate.getTime() - checkinDate.getTime();
        
        int totalPrice=this.getTotalPrice(diff,noOfRooms,tarrifPerDay);
       
        
        bookingDetails.setCheckInDate(checkinDate);
        bookingDetails.setCheckOutDate(checkoutDate);
        bookingDetails.setNumberOfRooms(noOfRooms);
        bookingDetails.setTotalPrice(totalPrice);
        bookingDetails.setUser(new User(userId));
        bookingDetails.setHotel(new Hotel(hotelId));
        System.out.println(bookingDetails);
        this.bookRoomDao.bookRoom(bookingDetails);
        
        return totalPrice;
	}

	private int getTotalPrice(long diff, Integer noOfRooms, Integer tarrifPerDay) {
		 int noOfDays = (int)( diff / (24 * 60 * 60 * 1000))+1;
	        int totalPrice=noOfDays * noOfRooms * tarrifPerDay;
		return totalPrice;
	}

	public List getUniqueBookingId() {
		// TODO Auto-generated method stub

        List bookingList=this.bookRoomDao.getUniquebookingId();
        return bookingList;
	}

}
