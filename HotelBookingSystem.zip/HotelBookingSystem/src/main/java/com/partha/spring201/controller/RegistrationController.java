package com.partha.spring201.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.partha.spring201.service.RegistrationService;

@Controller
public class RegistrationController {

	@Autowired
	RegistrationService registrationService;
	
	@RequestMapping(value="/register" , method=RequestMethod.POST)
	public String successfulRegistrationPage(@RequestParam("firstName") String firstName,@RequestParam("lastName") String lastName,
			@RequestParam("username") String username,
			@RequestParam("password") String password,ModelMap model){
		System.out.println(firstName);
		registrationService.saveUserInfo(firstName, lastName, username, password);
		model.addAttribute("registrationSuccessful","Registration Successful");
		return "main";
	}
}
