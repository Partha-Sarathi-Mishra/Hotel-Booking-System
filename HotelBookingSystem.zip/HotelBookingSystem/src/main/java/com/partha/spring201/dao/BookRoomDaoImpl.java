package com.partha.spring201.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.partha.spring201.model.BookingDetails;

@ComponentScan("com.partha.spring201.configuration")
@Repository
public class BookRoomDaoImpl implements BookRoomDao{

	@Autowired
	SessionFactory sessionFactory;
	
	@Autowired
	BookingDetails bookingDetails;
	

	public void bookRoom(BookingDetails bookingDetails) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(bookingDetails);
		tx.commit();
		session.close();
	}


	public List getUniquebookingId() {

		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		String hql="FROM BookingDetails ORDER BY booking_Id DESC";
        
		Query query=session.createQuery(hql).setMaxResults(1);
		List bookingList = query.list();
		System.out.println(bookingList);		
		tx.commit();
		session.close();
		return bookingList;
	}

}
