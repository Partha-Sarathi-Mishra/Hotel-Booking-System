package com.partha.spring201.dao;

import java.util.List;

public interface LoginDao {
	@SuppressWarnings("rawtypes")
	public List retriveUserUsernameAndPassword(String username,String password);
}
