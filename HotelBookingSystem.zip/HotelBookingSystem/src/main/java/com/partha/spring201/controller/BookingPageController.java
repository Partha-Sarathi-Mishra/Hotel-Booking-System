package com.partha.spring201.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BookingPageController {
	
	@RequestMapping(value="/booking", method=RequestMethod.POST)
	public String gotoBookingPage(@RequestParam("hotelName") String hotelName,
			@RequestParam("city") String city,@RequestParam Integer hotelId,
			@RequestParam("tarrifPerDay") Integer tarrifPerDay,ModelMap model){
		model.put("hotelName", hotelName);
		model.put("city", city);
		model.put("hotelId", hotelId);
		model.put("tarrifPerDay", tarrifPerDay);
		return "bookingPage";		
	}
}
