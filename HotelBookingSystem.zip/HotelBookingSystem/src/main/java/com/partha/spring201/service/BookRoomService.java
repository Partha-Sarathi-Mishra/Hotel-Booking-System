package com.partha.spring201.service;

import java.util.List;

public interface BookRoomService {

	public int bookRoom(String checkInDate, String checkOutDate, Integer noOfRooms,
			Integer hotelId, Integer userId, Integer tarrifPerDay);

	public List getUniqueBookingId();

}
