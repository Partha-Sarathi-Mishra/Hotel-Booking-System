package com.partha.spring201.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.partha.spring201.aspect.ApplicationAspects;
import com.partha.spring201.service.LoginService;

@Controller
@ComponentScan("com.partha.spring201.configuration")
@Scope("session")
@SessionAttributes("retrivedUser")
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	
	@SuppressWarnings("rawtypes")
	private List retrivedUser;
	
	@RequestMapping(value="/login" , method=RequestMethod.POST)
	public String successfulLoginPage(@RequestParam("username") String username,
				@RequestParam("password") String password,ModelMap model){
		retrivedUser = loginService.performLogin(username, password);
		if(retrivedUser.isEmpty()){
			model.addAttribute("loginError", "Invalid Username or Password");
			return "main";
		}
		model.put("retrivedUser", retrivedUser);
		
		
		return "loginSuccessful";
	}
}
