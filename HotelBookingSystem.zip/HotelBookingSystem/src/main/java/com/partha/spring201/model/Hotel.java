package com.partha.spring201.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="hotel_list")
public class Hotel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	int hotel_id;
	@NotNull(message="Can't be null")
	@Size(min = 2, max = 30)
	String	hotel_name;
	@NotNull(message="Can't be null")
	@Size(min = 2, max = 30)
	String	city;
	@NotNull(message="Can't be null")
	@Min(1)
	int	number_of_rooms;
	String	star_rating;
	@NotNull(message="Can't be null")
	int	tarrif_per_day;
	
	@OneToMany(mappedBy="hotel")
	private Set<BookingDetails> booking = new HashSet<BookingDetails>(0);
	
	/**
	 * @return the booking
	 */
	public Set<BookingDetails> getBooking() {
		return booking;
	}

	/**
	 * @param booking the booking to set
	 */
	public void setBooking(Set<BookingDetails> booking) {
		this.booking = booking;
	}
	
	public Hotel(){}
	public Hotel(int hotel_id){
		super();
		this.hotel_id = hotel_id;
		
	}
	
	public Hotel(int hotel_id, String hotel_name, String city, int number_of_rooms, String star_rating,
			int tarrif_per_day) {
		super();
		this.hotel_id = hotel_id;
		this.hotel_name = hotel_name;
		this.city = city;
		this.number_of_rooms = number_of_rooms;
		this.star_rating = star_rating;
		this.tarrif_per_day = tarrif_per_day;
	}
	public int getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}
	public String getHotel_name() {
		return hotel_name;
	}
	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getNumber_of_rooms() {
		return number_of_rooms;
	}
	public void setNumber_of_rooms(int number_of_rooms) {
		this.number_of_rooms = number_of_rooms;
	}
	public String getStar_rating() {
		return star_rating;
	}
	public void setStar_rating(String star_rating) {
		this.star_rating = star_rating;
	}
	public int getTarrif_per_day() {
		return tarrif_per_day;
	}
	public void setTarrif_per_day(int tarrif_per_day) {
		this.tarrif_per_day = tarrif_per_day;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + hotel_id;
		result = prime * result + ((hotel_name == null) ? 0 : hotel_name.hashCode());
		result = prime * result + number_of_rooms;
		result = prime * result + ((star_rating == null) ? 0 : star_rating.hashCode());
		result = prime * result + tarrif_per_day;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hotel other = (Hotel) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (hotel_id != other.hotel_id)
			return false;
		if (hotel_name == null) {
			if (other.hotel_name != null)
				return false;
		} else if (!hotel_name.equals(other.hotel_name))
			return false;
		if (number_of_rooms != other.number_of_rooms)
			return false;
		if (star_rating == null) {
			if (other.star_rating != null)
				return false;
		} else if (!star_rating.equals(other.star_rating))
			return false;
		if (tarrif_per_day != other.tarrif_per_day)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Hotel [hotel_id=" + hotel_id + ", hotel_name=" + hotel_name
				+ ", city=" + city + ", number_of_rooms=" + number_of_rooms
				+ ", star_rating=" + star_rating + ", tarrif_per_day="
				+ tarrif_per_day + "]";
	}
	
}
