package com.partha.spring201.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.partha.spring201.service.BookRoomService;

@Controller
public class BookRoomController {
	
	@Autowired
	private BookRoomService bookRoomService;
	
	
	

	
	@RequestMapping(value="bookRoom", method=RequestMethod.POST)
	public String successfulRoomBook(@RequestParam("checkInDate") String checkInDate,
			@RequestParam("checkOutDate") String checkOutDate, @RequestParam("noOfRooms") Integer noOfRooms,
			@RequestParam("userId") Integer userId,
			@RequestParam("hotelId") Integer hotelId,
			@RequestParam("tarrifPerDay") Integer tarrifPerDay,
			@RequestParam("hotelName") String hotelName,@RequestParam("cityName") String cityName,ModelMap model){
		
		int totalPrice=this.bookRoomService.bookRoom(checkInDate,checkOutDate,noOfRooms,hotelId,userId,tarrifPerDay);
	    model.addAttribute("checkOutDate", checkOutDate);
	    model.addAttribute("checkInDate", checkInDate);
	    model.addAttribute("noOfRooms", noOfRooms);
	    model.addAttribute("hotelName", hotelName);
	    model.addAttribute("cityName", cityName);
	    model.addAttribute("totalPrice",totalPrice);
	    List bookingList = this.bookRoomService.getUniqueBookingId();
	    model.addAttribute("bookingList",bookingList);
		return "roomBookSuccess";
	}
}
