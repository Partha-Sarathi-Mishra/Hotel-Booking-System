package com.partha.spring201.service;

import java.util.List;

import com.partha.spring201.model.Hotel;

public interface LoginHomePageService {

	public List<Hotel> getHotelsByCity(String selectedCity);

}
