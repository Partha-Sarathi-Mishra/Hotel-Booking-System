package com.partha.spring201.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.partha.spring201.dao.LoginHomePageDao;
import com.partha.spring201.model.Hotel;

@Service
public class LoginHomePageServiceImpl implements LoginHomePageService {

	@Autowired
	LoginHomePageDao loginHomePageDao;
	
	public List<Hotel> getHotelsByCity(String selectedCity) {
		return loginHomePageDao.getHotelsByCity(selectedCity);
	}

}
