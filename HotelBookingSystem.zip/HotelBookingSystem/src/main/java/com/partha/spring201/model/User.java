package com.partha.spring201.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;


@Entity
@Table(name = "hbs_users")
@Scope("session")
public class User {
		
		
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Integer user_id;
		//@Column(nullable = false, length = 30)
		@NotNull(message="Can't be null")
		@Size(min = 2, max = 30)
		private String user_first_name;
		//@Column(nullable = false, length = 30)
		@NotNull(message="Can't be null")
		@Size(min = 2, max = 30)
		private String user_last_name;
		//@Column(nullable = false, length = 30)
		@NotNull(message="Can't be null")
		@Size(min = 6, max = 30)
		private String username;
		//@Column(nullable = false, length = 30)
		@NotNull(message="Can't be null")
		@Size(min = 4, max = 30)
		private String password;
		
		@OneToMany(mappedBy="user")
		private Set<BookingDetails> booking = new HashSet<BookingDetails>(0);
		
		/**
		 * @return the booking
		 */
		public Set<BookingDetails> getBooking() {
			return booking;
		}

		/**
		 * @param booking the booking to set
		 */
		public void setBooking(Set<BookingDetails> booking) {
			this.booking = booking;
		}

		public User(){}
		
		public User(Integer user_id){
			
			super();
			this.user_id = user_id;
		}
		
		public User(Integer user_id, String user_first_name, String user_nast_name, String username, String password) {
			super();
			this.user_id = user_id;
			this.user_first_name = user_first_name;
			this.user_last_name = user_nast_name;
			this.username = username;
			this.password = password;
		}



		public Integer getUser_id() {
			return user_id;
		}

		public void setUser_id(Integer user_id) {
			this.user_id = user_id;
		}

		public String getUser_first_name() {
			return user_first_name;
		}

		public void setUser_first_name(String user_first_name) {
			this.user_first_name = user_first_name;
		}

		public String getUser_last_name() {
			return user_last_name;
		}

		public void setUser_last_name(String user_nast_name) {
			this.user_last_name = user_nast_name;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		
		
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((password == null) ? 0 : password.hashCode());
			result = prime * result + ((user_first_name == null) ? 0 : user_first_name.hashCode());
			result = prime * result + ((user_id == null) ? 0 : user_id.hashCode());
			result = prime * result + ((user_last_name == null) ? 0 : user_last_name.hashCode());
			result = prime * result + ((username == null) ? 0 : username.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			User other = (User) obj;
			if (password == null) {
				if (other.password != null)
					return false;
			} else if (!password.equals(other.password))
				return false;
			if (user_first_name == null) {
				if (other.user_first_name != null)
					return false;
			} else if (!user_first_name.equals(other.user_first_name))
				return false;
			if (user_id == null) {
				if (other.user_id != null)
					return false;
			} else if (!user_id.equals(other.user_id))
				return false;
			if (user_last_name == null) {
				if (other.user_last_name != null)
					return false;
			} else if (!user_last_name.equals(other.user_last_name))
				return false;
			if (username == null) {
				if (other.username != null)
					return false;
			} else if (!username.equals(other.username))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "User [user_id=" + user_id + ", user_first_name=" + user_first_name + ", user_nast_name="
					+ user_last_name + ", username=" + username + ", password=" + password + "]";
		}
}