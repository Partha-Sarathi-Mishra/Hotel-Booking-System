package com.partha.spring201.aspect;

import java.util.Arrays;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ApplicationAspects {
	static final Logger logger = Logger.getLogger(ApplicationAspects.class);

	@Before("execution(* com.partha.spring201.controller.*.*(..)")
	public void beforeControllerAdvice(JoinPoint joinPoint){
		logger.info("Before running beforeControllerAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
	@AfterReturning(pointcut="execution(* com.partha.spring201.controller.*.*(..)",returning="result")
	public void afterControllerAdvice(JoinPoint joinPoint,Object result){
		logger.info("After running beforeControllerAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));
		
		logger.info("returns : " + result);

	}
	@Before("execution(* com.partha.spring201.service.*(..)")
	public void beforeServiceAdvice(JoinPoint joinPoint){
		logger.info("Before running beforeServiceAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
	@AfterReturning(pointcut="execution(* com.partha.spring201.service.*.*(..)",returning="result")
	public void afterServiceAdvice(JoinPoint joinPoint,Object result){
		logger.info("After running afterServiceAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
	@Before("execution(* com.partha.spring201.dao.*.*(..)")
	public void beforeDaoAdvice(JoinPoint joinPoint){
		logger.info("Before running beforeDaoAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
	@AfterReturning(pointcut="execution(* com.partha.spring201.dao.*.*(..)",returning="result")
	public void afterDaoAdvice(JoinPoint joinPoint,Object result){
		logger.info("After running afterDaoAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
	@Before("execution(* com.partha.spring201.model.*.*(..)")
	public void beforeModelAdvice(JoinPoint joinPoint){
		logger.info("Before running beforeModelAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
	@AfterReturning(pointcut="execution(* com.partha.spring201.model.*.*(..)",returning="result")
	public void afterModelAdvice(JoinPoint joinPoint,Object result){
		logger.info("After running afterModelAdvice on method="+joinPoint.toString());
		
		logger.info("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
}
