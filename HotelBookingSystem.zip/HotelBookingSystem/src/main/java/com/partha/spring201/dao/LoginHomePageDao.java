package com.partha.spring201.dao;

import java.util.List;

import com.partha.spring201.model.Hotel;

public interface LoginHomePageDao {

	public List<Hotel> getHotelsByCity(String selectedCity);

}
